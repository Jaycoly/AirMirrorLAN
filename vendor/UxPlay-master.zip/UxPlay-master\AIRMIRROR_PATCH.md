# AirMirror LAN Windows mDNS interface patch

AirMirror LAN adds support for the `UXPLAY_MDNS_IPV4` environment variable in
`lib/mdnsd/mdnsd.c`.

On Windows, the multicast route can prefer a Wi-Fi Direct, mobile-hotspot, VPN,
or other virtual adapter even while the iPhone is connected through the normal
WLAN adapter. The unmodified internal mDNS responder then publishes AirPlay on
the wrong interface. When `UXPLAY_MDNS_IPV4` contains a valid IPv4 address, the
patched responder joins and sends on that interface. If it is absent or invalid,
the original UxPlay automatic selection remains unchanged.

The GUI determines this value using the Windows default IPv4 route. No global
adapter setting is changed.
